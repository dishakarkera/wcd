package model;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import org.hibernate.annotations.CreationTimestamp;

@Entity
@Table(name="Ngo")
public class Ngo implements Serializable{
	@Id
	@Column(name="id")
	@GeneratedValue(strategy=GenerationType.AUTO)
	private Integer ngoId;
	@Column
private String uuid;
	@Column
private String name;
	@Column
private String userType;
	@Column
private String address;
	@Column
private long pincode;
	@Column
private String email;
	@Column
private long mobileNo;
	@Column
private String password;
	
public Integer getNgoId() {
	return ngoId;
}
public void setNgoId(Integer ngoId) {
	this.ngoId = ngoId;
}
public String getUuid() {
	return uuid;
}
public void setUuid(String uuid) {
	this.uuid = uuid;
}
public String getName() {
	return name;
}
public void setName(String name) {
	this.name = name;
}
public String getUserType() {
	return userType;
}
public void setUserType(String userType) {
	this.userType = userType;
}
public String getAddress() {
	return address;
}
public void setAddress(String address) {
	this.address = address;
}
public long getPincode() {
	return pincode;
}
public void setPincode(long pincode) {
	this.pincode = pincode;
}
public String getEmail() {
	return email;
}
public void setEmail(String email) {
	this.email = email;
}
public long getMobileNo() {
	return mobileNo;
}
public void setMobileNo(long mobileNo) {
	this.mobileNo = mobileNo;
}
public String getPassword() {
	return password;
}
public void setPassword(String password) {
	this.password = password;
}
@Override
public String toString() {
	return "Ngo [ngoId=" + ngoId + ", uuid=" + uuid + ", name=" + name + ", userType=" + userType + ", address="
			+ address + ", pincode=" + pincode + ", email=" + email + ", mobileNo=" + mobileNo + ", password="
			+ password + "]";
}
public Ngo(Integer ngoId, String uuid, String name, String userType, String address, long pincode, String email,
		long mobileNo, String password) {
	super();
	this.ngoId = ngoId;
	this.uuid = uuid;
	this.name = name;
	this.userType = userType;
	this.address = address;
	this.pincode = pincode;
	this.email = email;
	this.mobileNo = mobileNo;
	this.password = password;
}
public Ngo() {
	super();
}

}
