package com.wcd.controller;

import javax.servlet.http.HttpServletRequest;
import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.wcd.service.IUserService;


import model.User;

public class UserController {
	private IUserService userService;

	@Autowired
	public void setUserService(IUserService userService) {
		this.userService = userService;
	}
	@RequestMapping(value = "/Login", method = RequestMethod.GET)
	public String indexes() {
		
		return "login";
	}
	@RequestMapping(value = "/userModel", method = RequestMethod.GET)
	public String listNgo(Model model) {
		model.addAttribute("users", new User());// model
		return "user";
	}
	
	@RequestMapping(value = "/user/add", method = RequestMethod.POST)
	public String addNgo(@ModelAttribute("users") @Valid User n, BindingResult result, Model model) {
		if (!result.hasErrors()) {
			if (n.getUserId() == null) {
				this.userService.addUser(n);
				System.out.println("added record ..");
			} 
			return "redirect:/userModel";
		}
		// model.addAttribute("listNgo", this.ngoService.listNgo());
		System.out.println("going to view");
		return "user";

	}
	
	
	@RequestMapping(value = "/LoginForms", method = RequestMethod.POST)
	public String LoginValidation(Model model,HttpServletRequest req)
	{
		String username=req.getParameter("username");
		String password=req.getParameter("password");
		
		System.out.println("this is password"+password);
		if(userService.verifyUser(username, password))
		{System.out.println("success");
		return "sucess";
		}
		return "failure";

	}


}
