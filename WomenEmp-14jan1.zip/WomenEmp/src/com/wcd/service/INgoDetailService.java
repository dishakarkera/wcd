package com.wcd.service;

import java.util.List;

import model.NgoDetails;

public interface INgoDetailService {
	public void addNgoDet(NgoDetails n);//insert
	public void updateNgoDet(NgoDetails p);//update/modify
	public List<NgoDetails> listNgoDetail();//retrieve/listAll
	public NgoDetails getNgoDetById(int id);//search
	public void removeNgoDet(int id);//delete/remove
}
