package com.wcd.dao;

import java.util.List;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import model.Ngo;
import model.NgoDetails;
@Repository
public class NgoDetailDaoImpl implements INgoDetailDao{
	private static final Logger logger = LoggerFactory.getLogger(NgoDetailDaoImpl.class);

	private SessionFactory sessionFactory;
private Transaction tx;
	@Autowired
	public void setSessionFactory(SessionFactory sf) {
		this.sessionFactory = sf;
	}

	@Override
	public void addNgoDet(NgoDetails n) {
		Session session = this.sessionFactory.openSession();
		tx=session.beginTransaction();
		n.setStatus("In process");
		session.persist(n);
		logger.info("Ngodets saved successfully, Ngo Details="
		+ n);
		
		tx.commit();
		session.close();
		
	}

	@Override
	public void updateNgoDet(NgoDetails p) {
		Session session = 
				this.sessionFactory
				.openSession();
		tx=session.beginTransaction();
		session.update(p);
		logger.info("NgoDet updated successfully, "
				+ "NgoDet Details=" + p);
		tx.commit();
		session.close();
	}

	@Override
	public List<NgoDetails> listNgoDetail() {
		Session session = this.sessionFactory.openSession();
		tx=session.beginTransaction();
		List<NgoDetails> ngoDetList = session.createQuery("from NgoDetails").list();
		for (NgoDetails p : ngoDetList) {
			logger.info("Ngodet List::" + p);
		}
		tx.commit();
		session.close();
		return ngoDetList;
	}


	@Override
	public NgoDetails getNgoDetById(int id) {
		Session session = this.sessionFactory.openSession();
		tx=session.beginTransaction();
		NgoDetails p = (NgoDetails) session.load(NgoDetails.class, new Integer(id));
		logger.info("Ngodet loaded successfully, Ngodet details=" + p);
		tx.commit();
		session.close();
		return p;
	}

	@Override
	public void removeNgoDet(int id) {
		Session session = this.sessionFactory.openSession();
		tx=session.beginTransaction();
		NgoDetails p = 
		(NgoDetails) session.load(NgoDetails.class, new Integer(id));
		if (null != p) {
			p.setStatus("Rejected");
		//	session.delete(p);
		}else {
			logger.error
			("NgoDet NOT deleted, with ngo Id=" +id);
		}
		logger.info("NgoDet deleted successfully, NgoDet details=" + p);
		tx.commit();
		session.close();
	}

	@Override
	public void acceptNgoDet(int id) {
		Session session = this.sessionFactory.openSession();
		tx=session.beginTransaction();
		NgoDetails p = 
		(NgoDetails) session.load(NgoDetails.class, new Integer(id));
		p.setStatus("Accepted");
		tx.commit();
		session.close();
		
	}
	/*
	 * @Override public boolean showStatusNgo(String id) { Session session =
	 * this.sessionFactory.openSession(); tx=session.beginTransaction(); NgoDetails
	 * p = (NgoDetails) session.load(NgoDetails.class, new String(id)); String
	 * a=p.getStatus(); if(a=="In progress") { return false; }else {tx.commit();
	 * session.close(); return true;}
	 * 
	 * 
	 * } public boolean exist(String uuid) { Session session =
	 * sessionFactory.getCurrentSession(); String queryString =
	 * "select uuid from NgoDetails e where e.uuid= :uuid"; Query query =
	 * session.createQuery(queryString); query.setParameter("uuid", uuid); List<Ngo>
	 * l=query.list();
	 * 
	 * if(l.size()==0) { return false; } session.close(); return true;
	 * 
	 * }
	 */
	/*
	 * @Override public boolean showStatusNgo(String id) { Session session
	 * =this.sessionFactory.openSession(); tx=session.beginTransaction(); NgoDetails
	 * p = (NgoDetails) session.load(NgoDetails.class, new String(id)); String
	 * a=p.getStatus(); if(a=="In progress") { tx.commit(); session.close(); return
	 * false; } else { tx.commit(); session.close(); return true;}
	 * 
	 * 
	 * }
	 *  */
	 @Override public List<NgoDetails> listNgoByUuid(String uuid) {
		 Session session =sessionFactory.openSession(); 

		 System.out.println("in");
		/*
		 * NgoDetails p = (NgoDetails) session.load(NgoDetails.class, new
		 * Integer(uuid));
		 */
		 String queryString="from NgoDetails where uuid=:uuid";
		 System.out.println("in query");
		 Query query = session.createQuery(queryString); 
		 query.setParameter("uuid", uuid);
		 System.out.println("out");
	  List<NgoDetails>l=query.list();
	  for (NgoDetails p : l) {
			logger.info("Ngodet List::" + p);
		}
	  session.close(); return l;
	  
	  }
	
	}


