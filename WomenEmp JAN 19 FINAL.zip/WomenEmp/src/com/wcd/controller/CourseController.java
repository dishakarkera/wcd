package com.wcd.controller;

import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.wcd.exception.CustomException;
import com.wcd.service.ICourseService;

import model.Course;
import model.NgoDetails;


@Controller
public class CourseController {
	@Autowired
ICourseService courseservice;


	public void setCourseservice(ICourseService courseservice) {
		this.courseservice = courseservice;
	}
	
	@RequestMapping(value = "/courseModel", method = RequestMethod.GET)
	public String listCourse(Model model) {
		
		model.addAttribute("course", new Course());// model
		
		return "courseReg";// view name
	}
	
	
	
	
	
	
	@RequestMapping(value = "/about", method = RequestMethod.GET)
	public String aboutstep(Model model) {
	
		return "aboutStep";
	}
	
	
	
	
	

	// For add and update person both
	@RequestMapping(value = "/course/add", method = RequestMethod.POST)
	public String addCourseDet(
			@ModelAttribute("course") 
			@Valid Course p, 
			BindingResult result, 
			Model model) {
		
				this.courseservice.addCourseDet(p);
		return "courseReg";

	}
	@RequestMapping("/listCourse")    
    public String viewcourse(Model m){    
		m.addAttribute("coursedetail", new Course());
        m.addAttribute("courseDetailList",this.courseservice.listCourseDetail());  
        return "adminCourse";    
    }    
	@RequestMapping("/listCourses")    
    public String viewcourses(Model m){    
		m.addAttribute("coursedetail", new Course());
        m.addAttribute("courseDetailList",this.courseservice.listCourseDetail());  
        return "trainingSectors";    
    }   
	@RequestMapping("/removecourse/{courseId}")
	public String removeCourseDet(
			@PathVariable("courseId") int id) throws CustomException {
		if (id > 0) {
			this.courseservice.removeCourse(id);
		} else {
		
			throw new CustomException("Given Id Not Found","404");
		}
		return "redirect:/listCourse";
	}

	@RequestMapping("/editcourse/{courseId}")
	public String showEditCoursePage(
			@PathVariable("courseId") int id, Model model) {
		Course ngoDetObj = 
				this.courseservice.getCourseById(id);
		model.addAttribute("coursedetail", ngoDetObj);
		List<Course> ngoDetListObj =
				this.courseservice.listCourseDetail();
		model.addAttribute("courseDetailList", ngoDetListObj);
		return "adminCourse";// view name
	}
	@RequestMapping(value="/saveCourse",method = RequestMethod.POST)    
    public String SaveCourse(@ModelAttribute("coursedetail") Course n){    
		this.courseservice.updateCourseDet(n); 
        return "redirect:/listCourse";    
    }    
	@RequestMapping("/dropdownCourse")    
    public String dropdownCourse(Model m){    
		m.addAttribute("coursedetail", new Course());
		 m.addAttribute("courseDetailList",this.courseservice.listCourseDetail());
        return "dropdown";    
    }    
	@RequestMapping("/dropdown")
	public String dropdown(Model model) {
		List<Course> ngoDetListObj =
				this.courseservice.listCourseDetail();
		for (Course p : ngoDetListObj) {
			System.out.println("course List::" + p);
		}
		model.addAttribute("courseDetailList", ngoDetListObj);
		return "dropdown";// view name
	}
	
}
