package com.wcd.controller;

import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.SessionAttributes;

import com.wcd.exception.CustomException;
import com.wcd.service.ICourseService;
import com.wcd.service.INgoDetailService;
import com.wcd.service.IUserReg;

import model.Course;
import model.NgoDetails;
import model.UserRegistration;

@Controller
public class UserRegController {

			@Autowired
		private IUserReg iUserRegSer;
		
		public void setiUserRegSer(IUserReg iUserRegSer) {
			this.iUserRegSer = iUserRegSer;
		}
		@Autowired
		ICourseService courseservice;
		@Autowired
		  INgoDetailService ngodetService;

		public void setNgodetService(INgoDetailService ngodetService) {
			this.ngodetService = ngodetService;
		}


			public void setCourseservice(ICourseService courseservice) {
				this.courseservice = courseservice;
			}
			@RequestMapping(value = "/userRegModel", method = RequestMethod.GET)
			public String listUserReg(Model model) {
				
				
				model.addAttribute("userReg", new UserRegistration());// model
				model.addAttribute("course",new Course());

				
				model.addAttribute("courseDetailList", this.courseservice.listCourseDetail());
				model.addAttribute("ngodet",new NgoDetails());
				model.addAttribute("NgoDetailList", this.ngodetService.listNgoDetail());
				return "personalDetailReg";// view name
			}
			@RequestMapping(value = "/userRegdetail/add", method = RequestMethod.POST)
		public String addUserReg(
				
				@ModelAttribute("userReg")
				@Valid UserRegistration n,
				BindingResult result,
				Model model,HttpSession session) {
				System.out.println("hiii1");
					String ngoUser=n.getTrainingCourse().getNgoName();
					String courseName=n.getTrainingCourse().getCourseName();
					
					this.iUserRegSer.addUserReg(n);
					List<Course> courseList=this.courseservice.listCourseByCAO(n.getTrainingCourse().getNgoName(),n.getTrainingCourse().getCourseName());
					System.out.println("added record ..");
					model.addAttribute("regid",n.getUserRegId());
					model.addAttribute("name",n.getPersonalDetails().getFirstName());
					model.addAttribute("courseList",courseList);
					//session.setAttribute("username", n.getPersonalDetails().getFirstName());
					return "registerSucess";


			}
			@RequestMapping("/listUserAttendance")    
			public String viewUserAttend(Model m){    
				m.addAttribute("userReqdetail", new UserRegistration());
			    m.addAttribute("userReqDetailList",this.iUserRegSer.listUserRegDetail());  
			    return "userAttendance";    
			} 
			@RequestMapping("/Certi")    
			public String certi(Model m){    
				m.addAttribute("userReqdetail", new UserRegistration());
			    m.addAttribute("userReqDetailList",this.iUserRegSer.listUserRegDetail());  
			    return "generateCerti";    
			}  
	@RequestMapping("/listUserReq")    
	public String viewUserReq(Model m){    
		m.addAttribute("userReqdetail", new UserRegistration());
	    m.addAttribute("userReqDetailList",this.iUserRegSer.listUserRegDetail());  
	    return "adminTrainee";    
	}    
	@RequestMapping("/removeUserReq/{userReg.userRegId}")
	public String removeCourseDet1(
			@PathVariable("userReg.userRegId") int id) throws CustomException {
		if (id > 0) {
			this.iUserRegSer.removeUserReg(id);
		} else {
		
			throw new CustomException("Given Id Not Found","404");
		}
		return "redirect:/listUserReq";
	}

	@RequestMapping("/editUserReq/{userReg.userRegId}")
	public String showEditTraineePage(
			@PathVariable("userReg.userRegId") int id, Model model) {
		UserRegistration userReqDetObj = 
				this.iUserRegSer.getUserRegById(id);
		model.addAttribute("userReqdetail", userReqDetObj);
		List<UserRegistration> userReqDetListObj =
				this.iUserRegSer.listUserRegDetail();
		model.addAttribute("userReqDetailList", userReqDetListObj);
		return "adminTrainee";// view name
	}
	@RequestMapping(value="/saveUserReq",method = RequestMethod.POST)    
	public String SaveUserReq(
			@ModelAttribute("userReqdetail") UserRegistration n){    
		System.out.println("hii");
		this.iUserRegSer.updateUserReg(n); 
	    return "redirect:/listUserReq";    
	}    
	@RequestMapping("/acceptUserReq/{userReg.userRegId}")
	//@ExceptionHandler({ CustomException.class })
	public String acceptUserRegDet(
			@PathVariable("userReg.userRegId") 
			int id) throws CustomException {
		if (id > 0) {
			this.iUserRegSer.acceptUserReg(id);
			
		} else {
			throw new CustomException("Given Id Not Found","404");
		}
		return "redirect:/listUserReq";
	}
	@RequestMapping("/showStatusUser") public String statusUser(Model m){
		m.addAttribute("userReg", new UserRegistration());
		// m.addAttribute("ngoDetShowList", this.ngodetService.listNgoDetail());
		 return "userViewStatus"; }
		 
		 @RequestMapping("/UsershowStatus") //@ExceptionHandler({ CustomException.class })
		 public String showStatusUser(@RequestParam("userRegId")Integer userRegId,Model model,HttpServletRequest req) { 
			 
			 List<UserRegistration> userDet=this.iUserRegSer.listUserByRegId(userRegId);
			  for (UserRegistration p : userDet) {
					System.out.println("UserAppln List::" + p);
				}
				
			 model.addAttribute("userDetShowList",userDet);
			return "userViewStatus";
		 }
		 @RequestMapping("/AttendanceUser") public String AttendanceUser(Model m){
				m.addAttribute("userReg", new UserRegistration());
				// m.addAttribute("ngoDetShowList", this.ngodetService.listNgoDetail());
				 return "userViewAttendance"; }
				 
				 @RequestMapping("/UserAttendance") //@ExceptionHandler({ CustomException.class })
				 public String showAttendUser(@RequestParam("userRegId")Integer userRegId,Model model,HttpServletRequest req,HttpSession session) { 
					 UserRegistration n=this.iUserRegSer.getUserRegById(userRegId);
					 List<UserRegistration> userDet=this.iUserRegSer.listUserByRegId(userRegId);
					 session.setAttribute("username", n.getPersonalDetails().getFirstName()); 
					 session.setAttribute("course", n.getTrainingCourse().getCourseName()); 
					 session.setAttribute("ngo", n.getTrainingCourse().getNgoName()); 
					  for (UserRegistration p : userDet) {
							System.out.println("UserAppln List::" + p);
						}
						
					 model.addAttribute("userDetShowList",userDet);
					return "userViewAttendance";
				 }
		 @RequestMapping("/attendUserReq/{userReg.userRegId}")
		//@ExceptionHandler({ CustomException.class })
		public String attendUserRegDet(
				@PathVariable("userReg.userRegId") 
				int id) throws CustomException {
			if (id > 0) {
				this.iUserRegSer.attendUserReg(id);
				
			} else {
				throw new CustomException("Given Id Not Found","404");
			}
			return "redirect:/listUserAttendance";
		}


}
