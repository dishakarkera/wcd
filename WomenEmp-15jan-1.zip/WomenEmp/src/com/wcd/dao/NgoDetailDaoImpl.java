package com.wcd.dao;

import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;

import model.NgoDetails;

public class NgoDetailDaoImpl implements INgoDetailDao{
	private static final Logger logger = LoggerFactory.getLogger(NgoDetailDaoImpl.class);

	private SessionFactory sessionFactory;
private Transaction tx;
	@Autowired
	public void setSessionFactory(SessionFactory sf) {
		this.sessionFactory = sf;
	}

	@Override
	public void addNgoDet(NgoDetails n) {
		Session session = this.sessionFactory.openSession();
		tx=session.beginTransaction();
		session.persist(n);
		logger.info("Ngodets saved successfully, Ngo Details="
		+ n);
		tx.commit();
		session.close();
		
	}

	@Override
	public void updateNgoDet(NgoDetails p) {
		Session session = 
				this.sessionFactory
				.openSession();
		tx=session.beginTransaction();
		session.update(p);
		logger.info("NgoDet updated successfully, "
				+ "NgoDet Details=" + p);
		tx.commit();
		session.close();
	}

	@Override
	public List<NgoDetails> listNgoDetail() {
		Session session = this.sessionFactory.openSession();
		tx=session.beginTransaction();
		List<NgoDetails> ngoDetList = session.createQuery("from Ngodetails").list();
		for (NgoDetails p : ngoDetList) {
			logger.info("Ngodet List::" + p);
		}
		tx.commit();
		session.close();
		return ngoDetList;
	}


	@Override
	public NgoDetails getNgoDetById(int id) {
		Session session = this.sessionFactory.openSession();
		tx=session.beginTransaction();
		NgoDetails p = (NgoDetails) session.load(NgoDetails.class, new Integer(id));
		logger.info("Ngodet loaded successfully, Ngodet details=" + p);
		tx.commit();
		session.close();
		return p;
	}

	@Override
	public void removeNgoDet(int id) {
		Session session = this.sessionFactory.openSession();
		tx=session.beginTransaction();
		NgoDetails p = 
		(NgoDetails) session.load(NgoDetails.class, new Integer(id));
		if (null != p) {
			session.delete(p);
		}else {
			logger.error
			("Person NOT deleted, with person Id=" +id);
		}
		logger.info("Person deleted successfully, person details=" + p);
		tx.commit();
		session.close();
	}
		
	}


