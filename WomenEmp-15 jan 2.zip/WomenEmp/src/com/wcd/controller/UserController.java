package com.wcd.controller;

import java.util.HashMap;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import org.springframework.web.servlet.ModelAndView;


import com.wcd.exception.CustomException;
import com.wcd.service.IUserService;

import model.User;

@Controller
public class UserController {
	private IUserService userService;

	@Autowired
	public void setUserService(IUserService userService) {
		this.userService = userService;
	}

	@RequestMapping(value = "/userModel", method = RequestMethod.GET)
	public String listUser(Model model) {
		model.addAttribute("user", new User());// model
		return "users";// view name
	}
	@RequestMapping(value = "/UserLogin", method = RequestMethod.GET)
	public String indexes1() {
		return "userLogin";
	}
	// For add and update ngo both
	@RequestMapping(value = "/user/add", method = RequestMethod.POST)
	// @ExceptionHandler({ CustomException.class })
	public String addUser(@ModelAttribute("user") @Valid User n, BindingResult result, Model model) {
		System.out.println("in");
		if (!result.hasErrors()) {
			if (n.getUserId() == null) {
				

				this.userService.addUser(n);
				System.out.println("added record ..");
			} else {
				// existing ngo, call update
				// this.ngoService.updateNgo(n);
			}
			return "redirect:/userModel";
		}
		// model.addAttribute("listNgo", this.ngoService.listNgo());
		System.out.println("going to view");
		return "users";

	}
	@RequestMapping(value = "/UserLoginForms", method = RequestMethod.POST)
	public String LoginValidation1(Model model,HttpServletRequest req)
	{
		String email=req.getParameter("email");
		String password=req.getParameter("password");
		
		System.out.println("this is password"+password);
		if(userService.verifyUser(email, password))
		{System.out.println("success");
		return "sucess";
		}
		return "failure";

	}
	
	
	
}
