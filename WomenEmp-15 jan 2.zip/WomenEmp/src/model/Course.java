package model;

public class Course {

}
