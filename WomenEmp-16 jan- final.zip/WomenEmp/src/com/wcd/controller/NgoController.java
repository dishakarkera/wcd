package com.wcd.controller;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.SessionAttributes;
import org.springframework.web.servlet.ModelAndView;


import com.wcd.exception.CustomException;
import com.wcd.service.INgoService;

import model.Ngo;
import model.User;

@Controller
@SessionAttributes(value = "sessionuser")
public class NgoController {
	private INgoService ngoService;

	@Autowired
	public void setNgoService(INgoService ngoService) {
		this.ngoService = ngoService;
	}

	// @ExceptionHandler(CustomException.class)
	public ModelAndView handlePersonNotFoundException(CustomException ex) {
		Map<String, CustomException> model = new HashMap<String, CustomException>();
		model.put("exception", ex);
		return new ModelAndView("error", model);

	}

	// @ExceptionHandler(Exception.class)
	public ModelAndView handleException(Exception ex) {
		Map<String, Exception> model = new HashMap<String, Exception>();
		model.put("exception", ex);
		return new ModelAndView("error", model);

	}

	@RequestMapping(value = "/ngoModel", method = RequestMethod.GET)
	public String listNgo(Model model) {
		model.addAttribute("ngo", new Ngo());// model
		return "ngo";// view name
	}
	@RequestMapping(value = "/Login", method = RequestMethod.GET)
	public String indexes(Model model) {
		return "login";
	}
	// For add and update ngo both
	@RequestMapping(value = "/ngo/add", method = RequestMethod.POST)
	// @ExceptionHandler({ CustomException.class })
	public String addNgo(@ModelAttribute("ngo") @Valid Ngo n, BindingResult result, Model model) {
		if (!result.hasErrors()) {
			if (n.getNgoId() == null) {
				// new ngo, add it

				this.ngoService.addNgo(n);
				System.out.println("added record ..");
			} else {
				// existing ngo, call update
				// this.ngoService.updateNgo(n);
			}
			return "redirect:/ngoModel";
		}
		// model.addAttribute("listNgo", this.ngoService.listNgo());
		System.out.println("going to view");
		return "ngo";

	}
	@RequestMapping(value = "/LoginForms", method = RequestMethod.POST)
	public ModelAndView LoginValidation(@ModelAttribute("ngo") @Valid Ngo n,BindingResult result,Model model,HttpServletRequest req,HttpSession session)
	{ModelAndView mav=new ModelAndView();
		String uuid=req.getParameter("uuid");
		String password=req.getParameter("password");
		
		System.out.println("this is password"+password);
		if(ngoService.verifyUser(uuid, password))
		{System.out.println("success");
		Ngo sessionNgo=this.ngoService.returnNgo(n);
		session.setAttribute("loginNgo", sessionNgo);
		session.setAttribute("loginUuId", n.getUuid());
		session.setAttribute("loginPassword", n.getPassword());
		mav.addObject("NgoId",n.getNgoId());
		mav.setViewName("sucess");
		}else
			{mav.setViewName("failure");}
		return mav;

	}
	
	
	
	@RequestMapping("/showErrorPage/error")
	// @ExceptionHandler(Exception.class)
	public ModelAndView exception(Exception e) {

		ModelAndView mav = new ModelAndView("error");// view name
		mav.addObject("exName", e.getClass().getSimpleName());// model for ex name
		mav.addObject("exMessage", e.getMessage());// model for ex msg
		return mav;
	}
}
