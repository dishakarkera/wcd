package model;

import java.util.HashSet;
import java.util.List;
import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToMany;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.persistence.UniqueConstraint;

@Entity
@Table(name="Course",uniqueConstraints = {@UniqueConstraint(columnNames = {"courseName"})})
public class Course {
	@Id
	@Column(name="id")
	@GeneratedValue(strategy=GenerationType.AUTO)
private Integer courseId;
@Column(unique=true)
private String courseName;
@ManyToMany(fetch = FetchType.LAZY,
cascade = {
    CascadeType.PERSIST,
    CascadeType.MERGE
},
mappedBy = "courseList")
private Set<NgoDetails> ngoList=new HashSet<NgoDetails>();

private String courseDescription;
private String courseDuration;
private String courseTiming;
private String courseLocation;

public Integer getCourseId() {
	return courseId;
}
public void setCourseId(Integer courseId) {
	this.courseId = courseId;
}
public String getCourseName() {
	return courseName;
}
public void setCourseName(String courseName) {
	this.courseName = courseName;
}

public String getCourseDescription() {
	return courseDescription;
}
public void setCourseDescription(String courseDescription) {
	this.courseDescription = courseDescription;
}
public String getCourseDuration() {
	return courseDuration;
}
public void setCourseDuration(String courseDuration) {
	this.courseDuration = courseDuration;
}
public String getCourseTiming() {
	return courseTiming;
}
public void setCourseTiming(String timing) {
	this.courseTiming = timing;
}
public String getCourseLocation() {
	return courseLocation;
}
public void setCourseLocation(String location) {
	courseLocation = location;
}
public Set<NgoDetails> getNgoList() {
	return ngoList;
}
public void setNgoList(Set<NgoDetails> ngoList) {
	this.ngoList = ngoList;
}
@Override
public String toString() {
	return "Course [courseId=" + courseId + ", courseName=" + courseName + ", ngoList=" + ngoList
			+ ", courseDescription=" + courseDescription + ", courseDuration=" + courseDuration + ", courseTiming="
			+ courseTiming + ", courseLocation=" + courseLocation + "]";
}
public Course(Integer courseId, String courseName, Set<NgoDetails> ngoList, String courseDescription,
		String courseDuration, String courseTiming, String courseLocation) {
	super();
	this.courseId = courseId;
	this.courseName = courseName;
	this.ngoList = ngoList;
	this.courseDescription = courseDescription;
	this.courseDuration = courseDuration;
	this.courseTiming = courseTiming;
	this.courseLocation = courseLocation;
}
public Course() {
	super();
}


}
