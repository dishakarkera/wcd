package com.wcd.service;


import org.springframework.stereotype.Service;

import model.User;
@Service
public interface IUserService {
	public void addUser(User n);//insert
public boolean verifyUser(String username,String password);
	public User getUserDetails(int userDetailsId);
}
