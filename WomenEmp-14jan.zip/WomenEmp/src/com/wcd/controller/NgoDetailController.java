package com.wcd.controller;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.wcd.exception.CustomException;
import com.wcd.service.INgoDetailService;

import model.NgoDetails;

public class NgoDetailController {
	 @Autowired
	  INgoDetailService ngodetService;

	public void setNgodetService(INgoDetailService ngodetService) {
		this.ngodetService = ngodetService;
	}
	//@ExceptionHandler(CustomException.class)
	public ModelAndView handlePersonNotFoundException(CustomException ex) {
		Map<String, CustomException> model = new HashMap<String, CustomException>();
		model.put("exception", ex);
		return new ModelAndView("error", model);

	}

	//@ExceptionHandler(Exception.class)
	public ModelAndView handleException(Exception ex) {
		Map<String, Exception> model = new HashMap<String, Exception>();
		model.put("exception", ex);
		return new ModelAndView("error", model);

	}

	@RequestMapping(value = "/ngodetails", method = RequestMethod.GET)
	public String listNgoDetail(Model model) {
		model.addAttribute("ngodetail", new NgoDetails());// model
		model.addAttribute("ngoDetailList", 
				this.ngodetService.listNgoDetail());
		return "ngoDetails";// view name
	}

	// For add and update person both
	@RequestMapping(value = "/ngodetail/add", 
			method = RequestMethod.POST)
	//@ExceptionHandler({ CustomException.class })
	public String addNgoDet(
			@ModelAttribute("ngodetail") 
			@Valid NgoDetails p, 
			BindingResult result, 
			Model model) {
		if (!result.hasErrors()) {
			if (p.getDetailId() == null) {
				// new person, add it
				this.ngodetService.addNgoDet(p);
			} else {
				// existing person, call update
				this.ngodetService.updateNgoDet(p);
			}
			return "redirect:/ngodetails";
		}
		model.addAttribute("ngoDetailList", this.ngodetService.listNgoDetail());
		return "ngoDetails";

	}

	@RequestMapping("/remove/{id}")
	//@ExceptionHandler({ CustomException.class })
	public String removeNgoDet(@PathVariable("id") int id) throws CustomException {
		if (id > 0) {
			throw new CustomException("Given Id Not Found","404");
		} else {
			this.ngodetService.removeNgoDet(id);
		}
		return "redirect:/ngodetails";
	}

	@RequestMapping("/edit/{id}")
	public String showEditPersonPage(
			@PathVariable("id") int id, Model model) {
		NgoDetails ngoDetObj = 
				this.ngodetService.getNgoDetById(id);
		model.addAttribute("ngodetail", ngoDetObj);
		List<NgoDetails> ngoDetListObj =
				this.ngodetService.listNgoDetail();
		model.addAttribute("ngoDetailList", ngoDetListObj);
		return "ngoDetails";// view name
	}

	@RequestMapping("/showErrorPage/error")
	//@ExceptionHandler(Exception.class)
	public ModelAndView exception(Exception e) {

		ModelAndView mav = new ModelAndView("error");// view name
		mav.addObject("exName", e.getClass().getSimpleName());// model for ex name
		mav.addObject("exMessage", e.getMessage());// model for ex msg
		return mav;
	}
}
