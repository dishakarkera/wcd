package model;

import java.io.Serializable;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Embedded;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToOne;
import javax.persistence.Table;



@Entity
@Table(name = "UserRegistration")
public class UserRegistration implements Serializable {
	@Id
    @GeneratedValue(strategy = GenerationType.AUTO)
private int userRegId;
	 @OneToOne(cascade=CascadeType.ALL)
private PersonalDetails personalDetails;
	 
	 @OneToOne(cascade=CascadeType.ALL)
private FamilyDetails familyDetails;
	 @OneToOne(cascade=CascadeType.ALL)
private ContactDetails contactDetails;
	 @OneToOne(cascade=CascadeType.ALL)
 private TrainingCourse trainingCourse;
	 @Column
	 private String Status;
	public int getUserRegId() {
		return userRegId;
	}
	public void setUserRegId(int userRegId) {
		this.userRegId = userRegId;
	}
	public PersonalDetails getPersonalDetails() {
		return personalDetails;
	}
	public void setPersonalDetails(PersonalDetails personalDetails) {
		this.personalDetails = personalDetails;
	}
	public FamilyDetails getFamilyDetails() {
		return familyDetails;
	}
	public void setFamilyDetails(FamilyDetails familyDetails) {
		this.familyDetails = familyDetails;
	}
	public ContactDetails getContactDetails() {
		return contactDetails;
	}
	public void setContactDetails(ContactDetails contactDetails) {
		this.contactDetails = contactDetails;
	}
	public TrainingCourse getTrainingCourse() {
		return trainingCourse;
	}
	public void setTrainingCourse(TrainingCourse trainingCourse) {
		this.trainingCourse = trainingCourse;
	}
	public String getStatus() {
		return Status;
	}
	public void setStatus(String status) {
		Status = status;
	}
	@Override
	public String toString() {
		return "UserRegistration [userRedId=" + userRegId + ", personalDetails=" + personalDetails + ", familyDetails="
				+ familyDetails + ", contactDetails=" + contactDetails + ", trainingCourse=" + trainingCourse
				+ ", Status=" + Status + "]";
	}
	public UserRegistration(int userRedId, PersonalDetails personalDetails, FamilyDetails familyDetails,
			ContactDetails contactDetails, TrainingCourse trainingCourse, String status) {
		super();
		this.userRegId = userRedId;
		this.personalDetails = personalDetails;
		this.familyDetails = familyDetails;
		this.contactDetails = contactDetails;
		this.trainingCourse = trainingCourse;
		Status = status;
	}
	public UserRegistration() {
		super();
	}
	
}
