package com.wcd.dao;

import java.util.List;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import model.NgoDetails;
import model.UserRegistration;
@Repository
public class UserRegDaoImpl implements IUserRegDao{
	private static final Logger logger = 			
			LoggerFactory.getLogger(UserRegDaoImpl.class);

	private SessionFactory sessionFactory;
private Transaction tx;
	@Autowired
	public void setSessionFactory(SessionFactory sf) {
	this.sessionFactory = sf;
	}
	
	
	@Override
	public void addUserReg(UserRegistration userReg) {
		System.out.println("hiii3");
		Session session = this.sessionFactory.openSession();
		 tx = session.beginTransaction();
		 userReg.setStatus("In Process");
		session.persist(userReg);
	    
		logger.info("UserDetails saved successfully, User Details="
		+ userReg);
		tx.commit();
		session.close();
		
	}


	@Override
	public void updateUserReg(UserRegistration userReg) {
		Session session = this.sessionFactory.openSession();
		 tx = session.beginTransaction();
		session.update(userReg);
	    
		logger.info("UserDetails saved successfully, User Details="
		+ userReg);
		tx.commit();
		session.close();
		
	}


	@Override
	public List<UserRegistration> listUserReg() {
		Session session = this.sessionFactory.openSession();
		tx=session.beginTransaction();
		List<UserRegistration> courseDetList = session.createQuery("from UserRegistration").list();
		for (UserRegistration p : courseDetList) {
			logger.info("UserRegistration List::" + p);
		}
		tx.commit();
		session.close();
		return courseDetList;

	}


	@Override
	public UserRegistration getUserRegById(int id) {
		Session session = this.sessionFactory.openSession();
		tx=session.beginTransaction();
		UserRegistration p = (UserRegistration) session.load(UserRegistration.class, new Integer(id));
		logger.info("Course loaded successfully, Course details=" + p);
		tx.commit();
		session.close();
		return p;
	}


	@Override
	public void removeUserReg(int id) {
		Session session = this.sessionFactory.openSession();
		tx=session.beginTransaction();
		UserRegistration p = 
		(UserRegistration) session.load(UserRegistration.class, new Integer(id));
		if (null != p) {
			p.setStatus("Rejected");
			//session.delete(p);
		}else {
			logger.error
			("UserRegistration NOT deleted, with UserRegistration Id=" +id);
		}
		logger.info("UserRegistration deleted successfully, UserRegistration details=" + p);
		tx.commit();
		session.close();
		
	}


	@Override
	public void acceptUserReg(int id) {
		Session session = this.sessionFactory.openSession();
		tx=session.beginTransaction();
		UserRegistration p = 
		(UserRegistration) session.load(UserRegistration.class, new Integer(id));
		p.setStatus("Accepted");
		tx.commit();
		session.close();
		
	}

	

	@Override
	public List<UserRegistration> listUserByRegId(Integer userRegId) {
		Session session =sessionFactory.openSession(); 

		 System.out.println("in");
		/*
		 * NgoDetails p = (NgoDetails) session.load(NgoDetails.class, new
		 * Integer(uuid));
		 */
		 String queryString="from UserRegistration where userRegId=:userRegId";
		 System.out.println("in query");
		 Query query = session.createQuery(queryString); 
		 query.setParameter("userRegId", userRegId);
		 System.out.println("out");
	  List<UserRegistration>l=query.list();
	  for (UserRegistration p : l) {
			logger.info("Ngodet List::" + p);
		}
	  session.close(); return l;
	}
	}
