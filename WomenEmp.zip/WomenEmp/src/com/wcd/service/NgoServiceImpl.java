package com.wcd.service;

import java.io.Serializable;
import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.wcd.dao.INgoDao;

import model.Ngo;
@Service
public class NgoServiceImpl implements INgoService,Serializable{
	private INgoDao ngoDao;
	@Autowired
		public void setNgoDao(INgoDao ngoDao) {
	    this.ngoDao = ngoDao;
	}
		
	@Override
	@Transactional
	public void addNgo(Ngo n) {
	this.ngoDao.addNgo(n);
		
	}

	/*
	 * @Override public void updateNgo(Ngo n) { this.ngoDao.updateNgo(n);
	 * 
	 * }
	 * 
	 * @Override public List<Ngo> listNgo() { return this.ngoDao.listNgo(); }
	 * 
	 * @Override public void removeNgo(int id) { this.ngoDao.removeNgo(id);
	 * 
	 * }
	 * 
	 * @Override public Ngo getNgoById(int id) { return this.ngoDao.getNgoById(id);
	 * }
	 */

}
