package com.wcd.service;

import java.util.List;

import org.springframework.stereotype.Service;

import model.Ngo;
@Service
public interface INgoService {
	public void addNgo(Ngo n);//insert
	/*
	 * public Ngo getNgoById(int id); public void updateNgo(Ngo n);//update/modify
	 * public List<Ngo> listNgo();//retrieve/listAll
	 * 
	 * public void removeNgo(int id);//delete/remove
	 */}
