package com.wcd.dao;

import java.io.Serializable;
import java.util.List;

import javax.transaction.Transactional;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import model.Ngo;
@Repository
public class NgoDaoImpl implements INgoDao,Serializable{
	private static final Logger logger = 			
			LoggerFactory.getLogger(NgoDaoImpl.class);

	private SessionFactory sessionFactory;

	@Autowired
	public void setSessionFactory(SessionFactory sf) {
	this.sessionFactory = sf;
	}

	@Override
	@Transactional
	public void addNgo(Ngo n) {
		Session session = this.sessionFactory.openSession();
		session.save(n);
	    
		logger.info("Ngo saved successfully, Ngo Details="
		+ n);
	
		session.close();
	}

	/*
	 * @Override public void updateNgo(Ngo n) { Session session =
	 * this.sessionFactory .openSession(); session.update(n);
	 * logger.info("Ngo updated successfully, " + "Ngo Details=" + n);
	 * session.close(); }
	 * 
	 * @Override public List<Ngo> listNgo() { Session session =
	 * this.sessionFactory.openSession(); List<Ngo> ngolist =
	 * session.createQuery("from Ngo").list(); for (Ngo n : ngolist) {
	 * logger.info("Ngo List::" + n); } session.close(); return ngolist; }
	 * 
	 * @Override public void removeNgo(int id) { Session session =
	 * this.sessionFactory.openSession(); Ngo p = (Ngo) session.load(Ngo.class, new
	 * Integer(id)); if (null != p) { session.delete(p); }else { logger.error
	 * ("Ngo NOT deleted, with Ngo Id=" +id); }
	 * logger.info("Ngo deleted successfully, Ngo details=" + p); session.close(); }
	 * 
	 * @Override public Ngo getNgoById(int id) { Session session =
	 * this.sessionFactory.openSession(); Ngo n= (Ngo) session.load(Ngo.class, new
	 * Integer(id)); logger.info("Person loaded successfully, Person details=" + n);
	 * session.close(); return n; }
	 */
	/*
	 * public void register(User user) { String sql =
	 * "insert into users values(?,?,?,?,?,?,?)"; jdbcTemplate.update(sql, new
	 * Object[] { user.getUsername(), user.getPassword(), user.getFirstname(),
	 * user.getLastname(), user.getEmail(), user.getAddress(), user.getPhone() });
	 * 
	 * }
	 * 
	 * public User validateUser(Login login) { String sql =
	 * "select * from users where username='" + login.getUsername() +
	 * "' and password='" + login.getPassword() + "'"; List<User> users =
	 * jdbcTemplate.query(sql, new UserMapper()); return users.size() > 0 ?
	 * users.get(0) : null;
	 * 
	 * }
	 * 
	 * }
	 * 
	 * class UserMapper implements RowMapper<User> { public User mapRow(ResultSet
	 * rs, int arg1) throws SQLException { User user = new User();
	 * user.setUsername(rs.getString("username"));
	 * user.setPassword(rs.getString("password"));
	 * user.setFirstname(rs.getString("firstname"));
	 * user.setLastname(rs.getString("lastname"));
	 * user.setEmail(rs.getString("email"));
	 * user.setAddress(rs.getString("address")); user.setPhone(rs.getInt("phone"));
	 * return user;
	 * 
	 * }
	 */
	}
	
	

