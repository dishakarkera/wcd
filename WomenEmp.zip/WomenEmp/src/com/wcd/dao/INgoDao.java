package com.wcd.dao;

import java.util.List;

import org.springframework.stereotype.Repository;

import model.Ngo;
@Repository
public interface INgoDao {
	public void addNgo(Ngo n);//insert
	
	/*public Ngo getNgoById(int id);//search
	 * public void updateNgo(Ngo n);//update/modify public List<Ngo>
	 * listNgo();//retrieve/listAll
	 * 
	 * public void removeNgo(int id);//delete/remove
	 */}
