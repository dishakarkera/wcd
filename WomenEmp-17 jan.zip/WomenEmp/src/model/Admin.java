package model;

import javax.persistence.Entity;

@Entity
public class Admin {
private String userName;
private String password;
}
