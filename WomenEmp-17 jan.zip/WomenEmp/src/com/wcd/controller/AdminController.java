package com.wcd.controller;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import javax.validation.Valid;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import model.Admin;
import model.Ngo;
import model.User;


public class AdminController {
	@RequestMapping(value = "/AdminLogin", method = RequestMethod.GET)
	public String indexes(Model model) {
		model.addAttribute("login",new Admin());
		return "login";
	}
	
	
	
	/*
	 * @RequestMapping(value = "/AdminLoginForms", method = RequestMethod.POST)
	 * public ModelAndView LoginValidation(@ModelAttribute("login") @Valid Admin
	 * n,BindingResult result,Model model,HttpServletRequest req,HttpSession
	 * session) {ModelAndView mav=new ModelAndView(); String
	 * username=req.getParameter("userName"); String
	 * password=req.getParameter("password");
	 * 
	 * System.out.println("this is password"+password); if(verifyUser(uuid,
	 * password)) {System.out.println("success"); Ngo
	 * sessionNgo=this.ngoService.returnNgo(n); session.setAttribute("loginNgo",
	 * sessionNgo); Integer id= sessionNgo.getNgoId();
	 * session.setAttribute("loginId", id); session.setAttribute("loginName",
	 * sessionNgo.getName()); mav.addObject("NgoId",n.getNgoId());
	 * mav.setViewName("sucess"); }else {mav.setViewName("failure");} return mav;
	 * 
	 * 
	 * }
	 */
}
