package com.wcd.controller;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.wcd.exception.CustomException;
import com.wcd.service.INgoDetailService;

import model.NgoDetails;
@Controller
public class NgoDetailController {
	 @Autowired
	  INgoDetailService ngodetService;

	public void setNgodetService(INgoDetailService ngodetService) {
		this.ngodetService = ngodetService;
	}

	
	@RequestMapping(value = "/ngodetails", method = RequestMethod.GET)
	public String listNgoDetail(Model model) {
		model.addAttribute("ngodetail", new NgoDetails());// model
		
		return "ngoDetails";// view name
	}

	// For add and update person both
	@RequestMapping(value = "/ngodetail/add", 
			method = RequestMethod.POST)
	//@ExceptionHandler({ CustomException.class })
	public String addNgoDet(
			@ModelAttribute("ngodetail") 
			@Valid NgoDetails p, 
			BindingResult result, 
			Model model) {
				this.ngodetService.addNgoDet(p);
		return "ngoDetails";

	}
	@RequestMapping("/listNgo")    
    public String viewngo(Model m){    
		m.addAttribute("ngodetail", new NgoDetails());
        m.addAttribute("ngoDetailList",this.ngodetService.listNgoDetail());  
        return "adminNgo";    
    }  
	@RequestMapping("/userlistNgo")    
    public String userviewngo(Model m){    
		m.addAttribute("ngodetail", new NgoDetails());
        m.addAttribute("ngoDetailList",this.ngodetService.listNgoDetail());  
        return "userNgoDetails";    
    }  
	@RequestMapping("/remove/{detailId}")
	//@ExceptionHandler({ CustomException.class })
	public String removeNgoDet(@PathVariable("detailId") int id) throws CustomException {
		if (id > 0) {
			this.ngodetService.removeNgoDet(id);
			
		} else {
			throw new CustomException("Given Id Not Found","404");
		}
		return "redirect:/listNgo";
	}

	@RequestMapping("/edit/{detailId}")
	public String showEditPersonPage(
			@PathVariable("detailId") int id, Model model) {
		NgoDetails ngoDetObj = 
				this.ngodetService.getNgoDetById(id);
		model.addAttribute("ngodetail", ngoDetObj);
		List<NgoDetails> ngoListObj =
				this.ngodetService.listNgoDetail();
		model.addAttribute("ngoDetailList", ngoListObj);
		return "adminNgo";// view name
	}
	@RequestMapping(value="/editsave",method = RequestMethod.POST)    
    public String editsave(@ModelAttribute("ngodetail") NgoDetails n){    
		this.ngodetService.updateNgoDet(n);    
        return "redirect:/listNgo";    
    }    
	@RequestMapping("/accept/{detailId}")
	//@ExceptionHandler({ CustomException.class })
	public String acceptNgoDet(@PathVariable("detailId") int id) throws CustomException {
		if (id > 0) {
			this.ngodetService.acceptNgoDet(id);
			
		} else {
			throw new CustomException("Given Id Not Found","404");
		}
		return "redirect:/listNgo";
	}
	
	
	 @RequestMapping("/showStatusNgo") public String statusNgo(Model m){
	m.addAttribute("ngodetail", new NgoDetails());
	// m.addAttribute("ngoDetShowList", this.ngodetService.listNgoDetail());
	 return "viewStatus"; }
	 
	 @RequestMapping("/showStatus") //@ExceptionHandler({ CustomException.class })
	 public String showStatusNgo(@RequestParam("uuid")String uuid,Model model,HttpServletRequest req) { 
		 
		 List<NgoDetails> ngoDet=this.ngodetService.listNgoByUUId(uuid);
		  for (NgoDetails p : ngoDet) {
				System.out.println("Ngodet List::" + p);
			}
			List<NgoDetails> ngoListObj =
					this.ngodetService.listNgoDetail();
		 model.addAttribute("ngoDetShowList",ngoDet);
		return "viewStatus";
	 }
	 @RequestMapping("/showCourse")
	 public String courseNgo(Model m){
			m.addAttribute("ngodetail", new NgoDetails());
			// m.addAttribute("ngoDetShowList", this.ngodetService.listNgoDetail());
			 return "viewStatus"; }
	 /*
	 * @RequestMapping("/showStatus") //@ExceptionHandler({ CustomException.class })
	 * public String showStatusNgo(Model model,HttpServletRequest req) { String
	 * uuid=req.getParameter("uuid"); if (ngodetService.exist(uuid)) {boolean
	 * status=this.ngodetService.showStatusNgo(uuid); if(status) return
	 * "addCourse";} else {return "rejected";} return "declined";
	 * 
	 * 
	 * }
	 */
	/*
	 * @RequestMapping(value = "/showStatusNgo", method = RequestMethod.GET) public
	 * String statusNgo(Model model) { model.addAttribute("ngodetail", new
	 * NgoDetails());// model model.addAttribute("listngo",
	 * this.ngodetService.listNgoDetail()); return "viewStatus";// view name }
	 * 
	 * @RequestMapping(value="/showStatus",method = RequestMethod.POST)
	 * //@ExceptionHandler({ CustomException.class }) public String
	 * showStatusNgo(@ModelAttribute("ngodetail") NgoDetails n,Model
	 * model,HttpServletRequest req) { String uuid=req.getParameter("uuid");
	 * List<NgoDetails> ngoDet=this.ngodetService.exist(uuid); if(ngoDet != null)
	 * {boolean status= this.ngodetService.showStatusNgo(uuid); if(status) return
	 * "addCourse"; else return "rejected";} return "declined"; }
	 */
}
