create table Ngo (id number primary key,uuid number,name varchar2(30),userType varchar2(30),name varchar2(30),
address varchar2(30),pincode number,email varchar2(30),mobileNo number,password varchar2(30));
