package com.wcd.dao;

import java.util.List;

import org.springframework.stereotype.Repository;

import model.Ngo;
@Repository
public interface INgoDao {
	public void addNgo(Ngo n);//insert
	public boolean validateUser(Ngo login);
	}
