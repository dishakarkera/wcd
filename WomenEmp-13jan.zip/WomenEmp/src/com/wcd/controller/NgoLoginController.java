package com.wcd.controller;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.wcd.service.INgoService;

import model.Ngo;
@Controller
public class NgoLoginController {
	
	 private INgoService ngoService;


	  @Autowired
	  public void setNgoService(INgoService ngoService) {
		this.ngoService = ngoService;
	}

	@RequestMapping(value = "/login", method = RequestMethod.GET)
	  public String showLogin(Model model) {
	    model.addAttribute("ngo", new Ngo());// model
		return "ngoLogin";// view name

	  }

	  @RequestMapping(value = "/loginProcess", method = RequestMethod.POST)
	  public String loginProcess(@ModelAttribute("login") @Valid Ngo login, BindingResult result, Model model) {
	  
	    boolean ngo = ngoService.validateUser(login);
	    if (ngo==true) {
	   return "sucess";
	    } else {
	   
	    return "ngoLogin";}

	  }

	 
}
